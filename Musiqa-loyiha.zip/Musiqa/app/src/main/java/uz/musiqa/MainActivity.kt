package uz.musiqa

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*

class Song(val id: Long, val title: String, val artist: String)

class MainActivity : Activity() {
    private val all = ArrayList<Song>()
    private var shown = ArrayList<Song>()
    private val saved = HashSet<String>()
    private lateinit var prefs: SharedPreferences
    private var onlySaved = false
    private var shuffle = false
    private var repeat = false
    private var cur = -1
    private var mp: MediaPlayer? = null
    private lateinit var adapter: BaseAdapter
    private lateinit var now: TextView
    private lateinit var playBtn: Button
    private lateinit var tabAll: Button
    private lateinit var tabSaved: Button
    private lateinit var btnShuffle: Button
    private lateinit var btnRepeat: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("m", MODE_PRIVATE)
        saved.addAll(prefs.getStringSet("saved", emptySet())!!)
        buildUi()
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) load()
        else requestPermissions(arrayOf(perm), 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) load()
        else Toast.makeText(this, "Musiqalarni topish uchun ruxsat kerak", Toast.LENGTH_LONG).show()
    }

    private fun load() {
        all.clear()
        contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
            MediaStore.Audio.Media.IS_MUSIC + "!=0", null, null
        )?.use {
            while (it.moveToNext()) all.add(Song(it.getLong(0), it.getString(1) ?: "?", it.getString(2) ?: ""))
        }
        all.sortBy { it.title.lowercase() } // alifbo bo'yicha
        refresh()
    }

    private fun refresh() {
        val playing = shown.getOrNull(cur)
        shown = ArrayList(if (onlySaved) all.filter { saved.contains(it.id.toString()) } else all)
        cur = if (playing == null) -1 else shown.indexOfFirst { it.id == playing.id }
        tabAll.setTextColor(if (onlySaved) Color.GRAY else Color.BLACK)
        tabSaved.setTextColor(if (onlySaved) Color.BLACK else Color.GRAY)
        adapter.notifyDataSetChanged()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tabs = LinearLayout(this)
        tabAll = Button(this).apply { text = "Hammasi"; setOnClickListener { onlySaved = false; refresh() } }
        tabSaved = Button(this).apply { text = "★ Saqlanganlar"; setOnClickListener { onlySaved = true; refresh() } }
        tabs.addView(tabAll, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(tabSaved, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(tabs)

        val list = ListView(this)
        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(i: Int) = shown[i]
            override fun getItemId(i: Int) = shown[i].id
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val s = shown[i]
                val row = LinearLayout(this@MainActivity).apply { setPadding(24, 16, 8, 16); gravity = Gravity.CENTER_VERTICAL }
                val t = TextView(this@MainActivity).apply {
                    text = s.title + if (s.artist.isNotEmpty() && s.artist != "<unknown>") "\n" + s.artist else ""
                    textSize = 16f
                    setTextColor(if (i == cur) Color.parseColor("#1565C0") else Color.BLACK)
                }
                val star = TextView(this@MainActivity).apply {
                    val on = saved.contains(s.id.toString())
                    text = if (on) "★" else "☆"; textSize = 28f; setPadding(32, 8, 32, 8)
                    setTextColor(if (on) Color.parseColor("#FFB300") else Color.GRAY)
                    setOnClickListener {
                        val k = s.id.toString()
                        if (!saved.remove(k)) saved.add(k)
                        prefs.edit().putStringSet("saved", HashSet(saved)).apply()
                        refresh()
                    }
                }
                row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(star)
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, i, _ -> play(i) }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        now = TextView(this).apply { text = "Musiqa tanlang"; setPadding(24, 12, 24, 4); maxLines = 1 }
        root.addView(now)
        val bar = LinearLayout(this)
        fun btn(txt: String, f: () -> Unit) = Button(this).apply { text = txt; setOnClickListener { f() } }
            .also { bar.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        btnShuffle = btn("🔀") { shuffle = !shuffle; paint() }
        btn("⏮") { step(-1) }
        playBtn = btn("▶") { toggle() }
        btn("⏭") { step(1) }
        btnRepeat = btn("🔂") { repeat = !repeat; paint() }
        root.addView(bar)
        setContentView(root)
        paint()
    }

    private fun paint() {
        btnShuffle.alpha = if (shuffle) 1f else 0.4f
        btnRepeat.alpha = if (repeat) 1f else 0.4f
    }

    private fun play(i: Int) {
        if (i !in shown.indices) return
        cur = i
        try {
            mp?.release()
            mp = MediaPlayer().apply {
                setDataSource(this@MainActivity, ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, shown[i].id))
                setOnCompletionListener { if (repeat) { it.seekTo(0); it.start() } else step(1) }
                prepare(); start()
            }
            now.text = "♪ " + shown[i].title
            playBtn.text = "⏸"
        } catch (e: Exception) {
            Toast.makeText(this, "Ijro etib bo'lmadi", Toast.LENGTH_SHORT).show()
        }
        adapter.notifyDataSetChanged()
    }

    private fun step(d: Int) {
        if (shown.isEmpty()) return
        val n = if (shuffle && d > 0) shown.indices.random() else (cur + d + shown.size) % shown.size
        play(n)
    }

    private fun toggle() {
        val m = mp ?: return play(if (cur >= 0) cur else 0)
        if (m.isPlaying) { m.pause(); playBtn.text = "▶" } else { m.start(); playBtn.text = "⏸" }
    }

    override fun onDestroy() { mp?.release(); super.onDestroy() }
}
